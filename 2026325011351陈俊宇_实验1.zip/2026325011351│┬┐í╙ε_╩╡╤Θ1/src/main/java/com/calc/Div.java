package com.calc;

public class Div extends Operation{
    public Div(double num1, double num2) {
        super(num1, num2);
    }
    @Override
    public double getResult() {
        if(num2 == 0){
            throw new ArithmeticException("除数不能为0");
        }
        return num1 / num2;
    }
}
