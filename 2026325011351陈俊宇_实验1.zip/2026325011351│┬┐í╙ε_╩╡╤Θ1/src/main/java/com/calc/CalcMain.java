package com.calc;
import java.util.Scanner;

public class CalcMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("====四则运算计算器====");
        System.out.print("输入第一个数：");
        double a = sc.nextDouble();
        System.out.print("输入运算符(+ - * /)：");
        String op = sc.next();
        System.out.print("输入第二个数：");
        double b = sc.nextDouble();
        try{
            Operation o = OperationFactory.createOperation(op,a,b);
            double res = o.getResult();
            System.out.println("结果："+a+" "+op+" "+b+" = "+res);
        }catch (Exception e){
            System.out.println("错误："+e.getMessage());
        }
        sc.close();
    }
}
