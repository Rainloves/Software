package com.calc;

public class OperationFactory{
    public static Operation createOperation(String op,double n1,double n2){
        switch (op){
            case "+": return new Add(n1,n2);
            case "-": return new Sub(n1,n2);
            case "*": return new Mul(n1,n2);
            case "/": return new Div(n1,n2);
            default: throw new RuntimeException("不支持运算符，仅支持 + - * /");
        }
    }
}
